package controller;

public class PmtID {
	String pmt_id;
	String pmt_title;
	String pmt_description;
	
	public String getPmt_id() {
		return pmt_id;
	}
	public void setPmt_id(String pmt_id) {
		this.pmt_id = pmt_id;
	}
	public String getPmt_title() {
		return pmt_title;
	}
	public void setPmt_title(String pmt_title) {
		this.pmt_title = pmt_title;
	}
	public String getPmt_description() {
		return pmt_description;
	}
	public void setPmt_description(String pmt_description) {
		this.pmt_description = pmt_description;
	}
}
